# MindCare — GitHub Pages + private usage counts

## What this package counts
- **Total visits:** each page load after analytics is configured. Repeat visits count again.
- **Estimated visitor devices:** distinct anonymous browser IDs that have visited.
- **Estimated participants:** distinct anonymous browser IDs that saved at least one emotion check-in. This is NOT a verified count of students; one student can use more than one browser/device.
- **Total check-ins** and **visits today (UTC)**.

The site sends only a random browser-installation ID and event type (`visit` or `checkin`) for these counters. Journal text, emotion names, and optional notes are not sent. Journal entries/check-ins themselves remain in that browser's local storage. Local storage is not encrypted, so do not write identifying details on a shared device.

## Setup (one-time)

### 1. Create Supabase project
1. Create a project at https://supabase.com/ and open **SQL Editor**.
2. Open `supabase_setup.sql` from this package, copy the whole file, paste it into SQL Editor, and run it.
3. In **Project Settings / API** (or Connect), copy the Project URL and the publishable/anon key. **Never use the service_role/secret key in HTML.**
4. Open `index.html` and find `const CLOUD = {url:'YOUR_SUPABASE_PROJECT_URL', anonKey:'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY'};`. Replace both placeholders with your Project URL and publishable/anon key. Save.
5. In Supabase **Authentication → Users**, create the staff/admin account with an email and strong password. Copy that user's UUID.
6. Back in **SQL Editor**, run this one-line command after replacing the UUID: `insert into public.mindcare_staff(user_id) values ('PASTE-STAFF-USER-UUID-HERE');`
   Only users listed in `mindcare_staff` can see aggregate admin statistics.

### 2. Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload **all files inside this folder** to the repository root (especially `index.html`, `manifest.json`, `icon.svg`, and `sw.js`).
3. Open repository **Settings → Pages** and publish from the `main` branch and `/ (root)`.
4. Open the published HTTPS website. Visit tracking starts after the Supabase setup and successful network connection. Offline events queue in the browser and attempt to sync when online.

### 3. Open the admin dashboard
Use **Staff dashboard** in the website and sign in with the Supabase staff email/password created above. Press **Refresh statistics** to update the totals.

## Privacy and limitations
- This counts browser installations, not authenticated or verified students. It can be affected by cleared browser storage, multiple devices, shared devices, and spam.
- It does not upload journal content, emotion names, or optional notes.
- Never put a Supabase `service_role` or secret key in `index.html`.
- The admin statistics function checks that the signed-in user is explicitly listed in `mindcare_staff`; keep that table restricted.
- Before using with real students, have a responsible school adult review consent, data-retention, and local privacy requirements. This is a starter implementation and does not include robust anti-abuse/rate-limiting.
- GitHub Pages is public hosting: anyone with the site link can use the student features. The admin dashboard is protected separately by Supabase authentication.
