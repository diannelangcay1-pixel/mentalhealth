-- Run in Supabase SQL Editor. Never expose a service-role key in HTML.
create table if not exists public.mindcare_events (
 id bigint generated always as identity primary key,
 device_id text not null check (length(device_id) between 10 and 100),
 event_type text not null check (event_type in ('visit','checkin')),
 occurred_at timestamptz not null default now(),
 received_at timestamptz not null default now()
);
create table if not exists public.mindcare_staff (
 user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.mindcare_events enable row level security;
alter table public.mindcare_staff enable row level security;
revoke all on public.mindcare_events from anon,authenticated;
revoke all on public.mindcare_staff from anon,authenticated;
-- The anonymous function can only INSERT validated event counts, never read rows.
create or replace function public.log_mindcare_events(events jsonb)
returns void language plpgsql security definer set search_path = '' as $$
declare e jsonb;
begin
 if jsonb_typeof(events) <> 'array' or jsonb_array_length(events) > 25 then
  raise exception 'Invalid batch';
 end if;
 for e in select value from jsonb_array_elements(events) loop
  if e->>'event_type' not in ('visit','checkin')
     or length(coalesce(e->>'device_id','')) not between 10 and 100
     or (select count(*) from jsonb_object_keys(e)) <> 3 then
   raise exception 'Invalid event';
  end if;
  insert into public.mindcare_events(device_id,event_type,occurred_at)
  values (e->>'device_id',e->>'event_type',now());
 end loop;
end $$;
revoke all on function public.log_mindcare_events(jsonb) from public;
grant execute on function public.log_mindcare_events(jsonb) to anon, authenticated;
-- Admin-only aggregate function: signed-in users must be explicitly listed as staff.
create or replace function public.mindcare_admin_stats()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare result jsonb;
begin
 if auth.uid() is null or not exists(select 1 from public.mindcare_staff where user_id=auth.uid()) then
  raise exception 'Not authorized';
 end if;
 select jsonb_build_object(
  'visits',count(*) filter (where event_type='visit'),
  'devices',count(distinct device_id) filter (where event_type='visit'),
  'participants',count(distinct device_id) filter (where event_type='checkin'),
  'checkins',count(*) filter (where event_type='checkin'),
  'today_visits',count(*) filter (where event_type='visit' and received_at>=date_trunc('day',now()))
 ) into result from public.mindcare_events;
 return result;
end $$;
revoke all on function public.mindcare_admin_stats() from public;
grant execute on function public.mindcare_admin_stats() to authenticated;
-- Create an admin in Supabase Authentication > Users, then add its UUID here:
-- insert into public.mindcare_staff(user_id) values ('YOUR-STAFF-USER-UUID');
-- IMPORTANT: Public analytics can be spammed and should be rate-limited for production.
-- "participants" counts distinct browser installations with at least one check-in, NOT verified unique students.
-- Public event logging can be spammed; this is a school-project starter, not production anti-abuse protection.
